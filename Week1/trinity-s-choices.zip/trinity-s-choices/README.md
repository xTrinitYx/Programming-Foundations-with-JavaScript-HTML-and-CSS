# Trinity's Choices

A Pen created on CodePen.io. Original URL: [https://codepen.io/xTrinitYx/pen/QWmYQWw](https://codepen.io/xTrinitYx/pen/QWmYQWw).

